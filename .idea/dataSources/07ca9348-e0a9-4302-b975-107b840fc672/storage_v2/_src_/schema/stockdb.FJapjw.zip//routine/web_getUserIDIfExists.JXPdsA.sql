create
    definer = root@localhost procedure web_getUserIDIfExists(IN username varchar(255), IN pass varchar(255))
BEGIN
	SELECT id from user
    WHERE username = username AND password = pass;
END;

