create
    definer = root@localhost procedure web_insertNewProductOnHand(IN am float, IN userId int, IN productId int)
BEGIN
INSERT INTO products_on_hand (amount, shop_id, product_id) 
VALUES (am, (SELECT shop_id FROM user WHERE id = userId) , productId);
END;

