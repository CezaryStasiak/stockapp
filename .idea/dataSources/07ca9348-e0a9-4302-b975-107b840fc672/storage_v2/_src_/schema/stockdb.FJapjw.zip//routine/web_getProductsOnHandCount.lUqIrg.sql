create
    definer = root@localhost procedure web_getProductsOnHandCount(IN shopId int, IN productId int)
BEGIN
SELECT count(*) FROM products_on_hand AS c
WHERE shop_id = shopId AND product_id = productId;
END;

