create
    definer = root@localhost procedure web_getUserFirstNameByUserId(IN userId int)
BEGIN
	SELECT name FROM user
    WHERE id = userId;
END;

