create
    definer = root@localhost procedure web_getCurrentlyAvailableProducts()
BEGIN
SELECT id, name, unit, price FROM product
ORDER BY name;
END;

