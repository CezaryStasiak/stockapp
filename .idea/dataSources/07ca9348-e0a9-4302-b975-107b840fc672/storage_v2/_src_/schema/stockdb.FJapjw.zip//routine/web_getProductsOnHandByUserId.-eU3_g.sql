create
    definer = root@localhost procedure web_getProductsOnHandByUserId(IN userId int)
BEGIN
SELECT product.id, product.name, product.price, product.unit, products_on_hand.amount
from product
join products_on_hand on product.id = products_on_hand.product_id AND products_on_hand.shop_id = 
(SELECT shop_id FROM user WHERE id = userId)
ORDER BY product.name;
END;

