create
    definer = root@localhost procedure web_setProductsOnHandCount(IN am float, IN userId int, IN productId int)
BEGIN
UPDATE products_on_hand 
SET amount = am
WHERE shop_id = (SELECT shop_id FROM user WHERE id = userId) AND product_id = productId;
END;

