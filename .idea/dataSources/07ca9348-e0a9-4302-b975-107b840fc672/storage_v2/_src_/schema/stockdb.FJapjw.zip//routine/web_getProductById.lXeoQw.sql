create
    definer = root@localhost procedure web_getProductById(IN productId int)
BEGIN
SELECT id FROM product
WHERE id = productId;
END;

